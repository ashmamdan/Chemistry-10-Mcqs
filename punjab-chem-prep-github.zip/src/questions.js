export const questions = [
  {
    "id": 1,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "Froth flotation process is used to concentrate ore on which basis?",
    "options": [
      {
        "label": "A",
        "text": "Density basis"
      },
      {
        "label": "B",
        "text": "Concentration basis"
      },
      {
        "label": "C",
        "text": "Wetting basis"
      },
      {
        "label": "D",
        "text": "Magnetic basis"
      }
    ],
    "answer": "C"
  },
  {
    "id": 2,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "Concentration of copper ore is carried out by:",
    "options": [
      {
        "label": "A",
        "text": "Calcination"
      },
      {
        "label": "B",
        "text": "Roasting"
      },
      {
        "label": "C",
        "text": "Froth flotation"
      },
      {
        "label": "D",
        "text": "Distillation"
      }
    ],
    "answer": "C"
  },
  {
    "id": 3,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "What is the formula of urea?",
    "options": [
      {
        "label": "A",
        "text": "NH₂COONH₄"
      },
      {
        "label": "B",
        "text": "NH₂COONH₂"
      },
      {
        "label": "C",
        "text": "NH₂COOH"
      },
      {
        "label": "D",
        "text": "NH₂CONH₂"
      }
    ],
    "answer": "D"
  },
  {
    "id": 4,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "Red hair contains a compound of:",
    "options": [
      {
        "label": "A",
        "text": "Iron"
      },
      {
        "label": "B",
        "text": "Copper"
      },
      {
        "label": "C",
        "text": "Titanium"
      },
      {
        "label": "D",
        "text": "Molybdenum"
      }
    ],
    "answer": "D"
  },
  {
    "id": 5,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "When CO₂ is passed through ammoniacal brine, the only salt that precipitates is:",
    "options": [
      {
        "label": "A",
        "text": "NaHCO₃"
      },
      {
        "label": "B",
        "text": "NH₄HCO₃"
      },
      {
        "label": "C",
        "text": "Na₂CO₃"
      },
      {
        "label": "D",
        "text": "(NH₄)₂CO₃"
      }
    ],
    "answer": "A"
  },
  {
    "id": 6,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "In Solvay's process, NaHCO₃ can be obtained by maintaining the temperature at:",
    "options": [
      {
        "label": "A",
        "text": "10°C"
      },
      {
        "label": "B",
        "text": "15°C"
      },
      {
        "label": "C",
        "text": "20°C"
      },
      {
        "label": "D",
        "text": "25°C"
      }
    ],
    "answer": "B"
  },
  {
    "id": 7,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "The nitrogen present in urea is used by plants to synthesize:",
    "options": [
      {
        "label": "A",
        "text": "Sugar"
      },
      {
        "label": "B",
        "text": "Protein"
      },
      {
        "label": "C",
        "text": "Fats"
      },
      {
        "label": "D",
        "text": "DNA"
      }
    ],
    "answer": "B"
  },
  {
    "id": 8,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "Which is a raw material for urea?",
    "options": [
      {
        "label": "A",
        "text": "CO"
      },
      {
        "label": "B",
        "text": "CO₂"
      },
      {
        "label": "C",
        "text": "N₂"
      },
      {
        "label": "D",
        "text": "NO₂"
      }
    ],
    "answer": "B"
  },
  {
    "id": 9,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "Which is NOT a fraction of petroleum?",
    "options": [
      {
        "label": "A",
        "text": "Kerosene oil"
      },
      {
        "label": "B",
        "text": "Diesel oil"
      },
      {
        "label": "C",
        "text": "Alcohol"
      },
      {
        "label": "D",
        "text": "Petrol"
      }
    ],
    "answer": "C"
  },
  {
    "id": 10,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "What is the carbon range in fuel oil?",
    "options": [
      {
        "label": "A",
        "text": "C₇ to C₁₀"
      },
      {
        "label": "B",
        "text": "C₁₀ to C₁₂"
      },
      {
        "label": "C",
        "text": "C₁₃ to C₁₅"
      },
      {
        "label": "D",
        "text": "C₁₅ to C₁₈"
      }
    ],
    "answer": "D"
  },
  {
    "id": 11,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "Which is a fraction of residual oil?",
    "options": [
      {
        "label": "A",
        "text": "Petroleum gas"
      },
      {
        "label": "B",
        "text": "Petroleum ether"
      },
      {
        "label": "C",
        "text": "Diesel oil"
      },
      {
        "label": "D",
        "text": "Lubricants"
      }
    ],
    "answer": "D"
  },
  {
    "id": 12,
    "paper": "Paper 08",
    "section": "Chapter 16 — Chemical Industries",
    "question": "Which is a fraction of residual oil?",
    "options": [
      {
        "label": "A",
        "text": "Kerosene oil"
      },
      {
        "label": "B",
        "text": "Asphalt"
      },
      {
        "label": "C",
        "text": "Petrol"
      },
      {
        "label": "D",
        "text": "Petroleum ether"
      }
    ],
    "answer": "B"
  },
  {
    "id": 13,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "Substances formed during a chemical reaction are called:",
    "options": [
      {
        "label": "A",
        "text": "Products"
      },
      {
        "label": "B",
        "text": "Reactants"
      },
      {
        "label": "C",
        "text": "Radicals"
      },
      {
        "label": "D",
        "text": "Elements"
      }
    ],
    "answer": "A"
  },
  {
    "id": 14,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "Molar concentration is expressed in:",
    "options": [
      {
        "label": "A",
        "text": "{ }"
      },
      {
        "label": "B",
        "text": "[ ]"
      },
      {
        "label": "C",
        "text": "( )"
      },
      {
        "label": "D",
        "text": "All of these"
      }
    ],
    "answer": "B"
  },
  {
    "id": 15,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "The value of Kc depends upon:",
    "options": [
      {
        "label": "A",
        "text": "Pressure"
      },
      {
        "label": "B",
        "text": "Temperature"
      },
      {
        "label": "C",
        "text": "Volume"
      },
      {
        "label": "D",
        "text": "Density"
      }
    ],
    "answer": "B"
  },
  {
    "id": 16,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "If Qc > Kc, the reaction will proceed in the:",
    "options": [
      {
        "label": "A",
        "text": "Chemical equilibrium"
      },
      {
        "label": "B",
        "text": "Static equilibrium"
      },
      {
        "label": "C",
        "text": "Reverse direction"
      },
      {
        "label": "D",
        "text": "Forward direction"
      }
    ],
    "answer": "C"
  },
  {
    "id": 17,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "Malic acid is found in:",
    "options": [
      {
        "label": "A",
        "text": "Lemon"
      },
      {
        "label": "B",
        "text": "Sour milk"
      },
      {
        "label": "C",
        "text": "Orange"
      },
      {
        "label": "D",
        "text": "Apple"
      }
    ],
    "answer": "D"
  },
  {
    "id": 18,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "What is the chemical formula of sulphuric acid?",
    "options": [
      {
        "label": "A",
        "text": "H₂SO₄"
      },
      {
        "label": "B",
        "text": "HCl"
      },
      {
        "label": "C",
        "text": "HNO₃"
      },
      {
        "label": "D",
        "text": "NaCl"
      }
    ],
    "answer": "A"
  },
  {
    "id": 19,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "Arrhenius concept is applicable in:",
    "options": [
      {
        "label": "A",
        "text": "Non-aqueous medium"
      },
      {
        "label": "B",
        "text": "Aqueous medium"
      },
      {
        "label": "C",
        "text": "Alcoholic medium"
      },
      {
        "label": "D",
        "text": "Basic medium"
      }
    ],
    "answer": "B"
  },
  {
    "id": 20,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "Which is NOT composed of salt?",
    "options": [
      {
        "label": "A",
        "text": "A metallic cation"
      },
      {
        "label": "B",
        "text": "A non-metallic cation"
      },
      {
        "label": "C",
        "text": "An anion of a base"
      },
      {
        "label": "D",
        "text": "An anion of an acid"
      }
    ],
    "answer": "B"
  },
  {
    "id": 21,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "What is the formula of pentane?",
    "options": [
      {
        "label": "A",
        "text": "C₅H₁₂"
      },
      {
        "label": "B",
        "text": "C₅H₁₀"
      },
      {
        "label": "C",
        "text": "C₅H₈"
      },
      {
        "label": "D",
        "text": "C₅H₁₄"
      }
    ],
    "answer": "A"
  },
  {
    "id": 22,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "The benzene ring is an example of:",
    "options": [
      {
        "label": "A",
        "text": "Alicyclic compound"
      },
      {
        "label": "B",
        "text": "Aromatic compound"
      },
      {
        "label": "C",
        "text": "Heterocyclic compound"
      },
      {
        "label": "D",
        "text": "Straight-chain compound"
      }
    ],
    "answer": "B"
  },
  {
    "id": 23,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "Conversion of dead plants into coal by the action of bacteria and heat is called:",
    "options": [
      {
        "label": "A",
        "text": "Carbonization"
      },
      {
        "label": "B",
        "text": "Catenation"
      },
      {
        "label": "C",
        "text": "Hydrogenation"
      },
      {
        "label": "D",
        "text": "Cracking"
      }
    ],
    "answer": "A"
  },
  {
    "id": 24,
    "paper": "Paper 09",
    "section": "First Quarter — Units 9 to 11",
    "question": "Which compound is a ketone?",
    "options": [
      {
        "label": "A",
        "text": "(CH₃)₂CHOH"
      },
      {
        "label": "B",
        "text": "(CH₃)₂CO"
      },
      {
        "label": "C",
        "text": "(CH₃)₂NH"
      },
      {
        "label": "D",
        "text": "(CH₃)₂CHCl"
      }
    ],
    "answer": "B"
  },
  {
    "id": 25,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "Incomplete combustion of alkanes produces:",
    "options": [
      {
        "label": "A",
        "text": "Carbon dioxide only"
      },
      {
        "label": "B",
        "text": "Carbon monoxide only"
      },
      {
        "label": "C",
        "text": "Carbon monoxide and carbon black"
      },
      {
        "label": "D",
        "text": "Carbon dioxide and carbon black"
      }
    ],
    "answer": "C"
  },
  {
    "id": 26,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "A hydrocarbon reacts with one mole of H₂ to form a saturated hydrocarbon. A possible formula of X is:",
    "options": [
      {
        "label": "A",
        "text": "C₃H₈"
      },
      {
        "label": "B",
        "text": "C₆H₁₂"
      },
      {
        "label": "C",
        "text": "C₄H₁₀"
      },
      {
        "label": "D",
        "text": "C₇H₁₆"
      }
    ],
    "answer": "B"
  },
  {
    "id": 27,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "Hydrogenation of CH₂=CH₂ uses which catalyst?",
    "options": [
      {
        "label": "A",
        "text": "Ni"
      },
      {
        "label": "B",
        "text": "Na"
      },
      {
        "label": "C",
        "text": "Mg"
      },
      {
        "label": "D",
        "text": "Ca"
      }
    ],
    "answer": "A"
  },
  {
    "id": 28,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "The end product of oxidation of acetylene is:",
    "options": [
      {
        "label": "A",
        "text": "Oxalic acid"
      },
      {
        "label": "B",
        "text": "Glycol"
      },
      {
        "label": "C",
        "text": "Glyoxal"
      },
      {
        "label": "D",
        "text": "None"
      }
    ],
    "answer": "A"
  },
  {
    "id": 29,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "Which of the following is a triglyceride?",
    "options": [
      {
        "label": "A",
        "text": "Carbohydrates"
      },
      {
        "label": "B",
        "text": "Proteins"
      },
      {
        "label": "C",
        "text": "Lipids"
      },
      {
        "label": "D",
        "text": "Vitamins"
      }
    ],
    "answer": "C"
  },
  {
    "id": 30,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "Pentahydroxy ketone is called:",
    "options": [
      {
        "label": "A",
        "text": "Glucose"
      },
      {
        "label": "B",
        "text": "Starch"
      },
      {
        "label": "C",
        "text": "Sucrose"
      },
      {
        "label": "D",
        "text": "Fructose"
      }
    ],
    "answer": "D"
  },
  {
    "id": 31,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "Which is responsible for transmitting genetic information from one generation to the next?",
    "options": [
      {
        "label": "A",
        "text": "Protein"
      },
      {
        "label": "B",
        "text": "Nucleic acid"
      },
      {
        "label": "C",
        "text": "Carbohydrates"
      },
      {
        "label": "D",
        "text": "Lipids"
      }
    ],
    "answer": "B"
  },
  {
    "id": 32,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "The scientific name of vitamin C is:",
    "options": [
      {
        "label": "A",
        "text": "Acetic acid"
      },
      {
        "label": "B",
        "text": "Formic acid"
      },
      {
        "label": "C",
        "text": "Ascorbic acid"
      },
      {
        "label": "D",
        "text": "Lactic acid"
      }
    ],
    "answer": "C"
  },
  {
    "id": 33,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "The temperature range of the stratosphere is approximately:",
    "options": [
      {
        "label": "A",
        "text": "7°C to −91°C"
      },
      {
        "label": "B",
        "text": "2°C to −93°C"
      },
      {
        "label": "C",
        "text": "17°C to −58°C"
      },
      {
        "label": "D",
        "text": "−58°C to −2°C"
      }
    ],
    "answer": "D"
  },
  {
    "id": 34,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "Ozone is formed in the:",
    "options": [
      {
        "label": "A",
        "text": "Troposphere"
      },
      {
        "label": "B",
        "text": "Stratosphere"
      },
      {
        "label": "C",
        "text": "Mesosphere"
      },
      {
        "label": "D",
        "text": "Thermosphere"
      }
    ],
    "answer": "B"
  },
  {
    "id": 35,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "Atmospheric temperature increases every year due to accumulation of CO₂ by about:",
    "options": [
      {
        "label": "A",
        "text": "0.01°C"
      },
      {
        "label": "B",
        "text": "0.05°C"
      },
      {
        "label": "C",
        "text": "0.09°C"
      },
      {
        "label": "D",
        "text": "0.013°C"
      }
    ],
    "answer": "B"
  },
  {
    "id": 36,
    "paper": "Paper 10",
    "section": "Second Quarter — Units 12 to 14",
    "question": "The pH of acid rain is about:",
    "options": [
      {
        "label": "A",
        "text": "4"
      },
      {
        "label": "B",
        "text": "6"
      },
      {
        "label": "C",
        "text": "6.5"
      },
      {
        "label": "D",
        "text": "2"
      }
    ],
    "answer": "A"
  },
  {
    "id": 37,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "Water has maximum density at:",
    "options": [
      {
        "label": "A",
        "text": "0°C"
      },
      {
        "label": "B",
        "text": "100°C"
      },
      {
        "label": "C",
        "text": "4°C"
      },
      {
        "label": "D",
        "text": "−4°C"
      }
    ],
    "answer": "C"
  },
  {
    "id": 38,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "The percentage of water in the human body is about:",
    "options": [
      {
        "label": "A",
        "text": "68%"
      },
      {
        "label": "B",
        "text": "69%"
      },
      {
        "label": "C",
        "text": "70%"
      },
      {
        "label": "D",
        "text": "71%"
      }
    ],
    "answer": "C"
  },
  {
    "id": 39,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "Hardness of water is of how many types?",
    "options": [
      {
        "label": "A",
        "text": "2"
      },
      {
        "label": "B",
        "text": "3"
      },
      {
        "label": "C",
        "text": "4"
      },
      {
        "label": "D",
        "text": "5"
      }
    ],
    "answer": "A"
  },
  {
    "id": 40,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "Which salt makes water permanently hard?",
    "options": [
      {
        "label": "A",
        "text": "Na₂CO₃"
      },
      {
        "label": "B",
        "text": "NaHCO₂"
      },
      {
        "label": "C",
        "text": "Ca(HCO₃)₂"
      },
      {
        "label": "D",
        "text": "CaSO₄"
      }
    ],
    "answer": "D"
  },
  {
    "id": 41,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "Rapid algae growth in water bodies due to detergents is caused by:",
    "options": [
      {
        "label": "A",
        "text": "Carbonate salts"
      },
      {
        "label": "B",
        "text": "Sulphonic acid salts"
      },
      {
        "label": "C",
        "text": "Sulphate salts"
      },
      {
        "label": "D",
        "text": "Phosphate salts"
      }
    ],
    "answer": "D"
  },
  {
    "id": 42,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "Which disease causes severe diarrhea and can be fatal?",
    "options": [
      {
        "label": "A",
        "text": "Jaundice"
      },
      {
        "label": "B",
        "text": "Dysentery"
      },
      {
        "label": "C",
        "text": "Cholera"
      },
      {
        "label": "D",
        "text": "Typhoid"
      }
    ],
    "answer": "C"
  },
  {
    "id": 43,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "The chemical formula of chalcopyrite is:",
    "options": [
      {
        "label": "A",
        "text": "Cu₂S"
      },
      {
        "label": "B",
        "text": "CuFeS₂"
      },
      {
        "label": "C",
        "text": "CuS"
      },
      {
        "label": "D",
        "text": "FeS"
      }
    ],
    "answer": "B"
  },
  {
    "id": 44,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "Copper pyrite strongly heated in excess air converts into a mixture of:",
    "options": [
      {
        "label": "A",
        "text": "Cu₂O and FeS"
      },
      {
        "label": "B",
        "text": "Cu₂O and FeS₂"
      },
      {
        "label": "C",
        "text": "Cu₂S and FeS"
      },
      {
        "label": "D",
        "text": "Cu₂O and SO₂"
      }
    ],
    "answer": "C"
  },
  {
    "id": 45,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "A vigorous reaction of water with ___ can shatter glassware into small pieces.",
    "options": [
      {
        "label": "A",
        "text": "Sodium"
      },
      {
        "label": "B",
        "text": "Caesium"
      },
      {
        "label": "C",
        "text": "Strontium"
      },
      {
        "label": "D",
        "text": "Silicon"
      }
    ],
    "answer": "B"
  },
  {
    "id": 46,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "The nitrogen in urea is used by plants to synthesize:",
    "options": [
      {
        "label": "A",
        "text": "Sugar"
      },
      {
        "label": "B",
        "text": "Proteins"
      },
      {
        "label": "C",
        "text": "Fats"
      },
      {
        "label": "D",
        "text": "DNA"
      }
    ],
    "answer": "B"
  },
  {
    "id": 47,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "Concentration is a:",
    "options": [
      {
        "label": "A",
        "text": "Mixing technique"
      },
      {
        "label": "B",
        "text": "Separating technique"
      },
      {
        "label": "C",
        "text": "Boiling technique"
      },
      {
        "label": "D",
        "text": "Cooling technique"
      }
    ],
    "answer": "B"
  },
  {
    "id": 48,
    "paper": "Paper 11",
    "section": "Third Quarter — Units 15 to 16",
    "question": "The boiling range of petroleum ether is:",
    "options": [
      {
        "label": "A",
        "text": "170–250°C"
      },
      {
        "label": "B",
        "text": "30–80°C"
      },
      {
        "label": "C",
        "text": "20–170°C"
      },
      {
        "label": "D",
        "text": "80–170°C"
      }
    ],
    "answer": "B"
  },
  {
    "id": 49,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "In a chemical reaction, substances that combine are called:",
    "options": [
      {
        "label": "A",
        "text": "Reactants"
      },
      {
        "label": "B",
        "text": "Products"
      },
      {
        "label": "C",
        "text": "Equilibrium"
      },
      {
        "label": "D",
        "text": "Numerator"
      }
    ],
    "answer": "A"
  },
  {
    "id": 50,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "For N₂ + 3H₂ ⇌ 2NH₃, the equilibrium constant expression is:",
    "options": [
      {
        "label": "A",
        "text": "[2NH₃]²/[N₂][H₂]³"
      },
      {
        "label": "B",
        "text": "[NH₃]²/[N₂][H₂]³"
      },
      {
        "label": "C",
        "text": "[N₂][H₂]³/[NH₃]²"
      },
      {
        "label": "D",
        "text": "[NH₃]/[N₂][H₂]"
      }
    ],
    "answer": "B"
  },
  {
    "id": 51,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "If Qc > Kc, the reaction will proceed in the:",
    "options": [
      {
        "label": "A",
        "text": "Chemical equilibrium"
      },
      {
        "label": "B",
        "text": "Static equilibrium"
      },
      {
        "label": "C",
        "text": "Reverse direction"
      },
      {
        "label": "D",
        "text": "Forward direction"
      }
    ],
    "answer": "C"
  },
  {
    "id": 52,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "Which species is NOT amphoteric?",
    "options": [
      {
        "label": "A",
        "text": "H₂O"
      },
      {
        "label": "B",
        "text": "NH₃"
      },
      {
        "label": "C",
        "text": "HCO₃⁻"
      },
      {
        "label": "D",
        "text": "SO₄²⁻"
      }
    ],
    "answer": "D"
  },
  {
    "id": 53,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "Which base is used in alkaline batteries?",
    "options": [
      {
        "label": "A",
        "text": "NaOH"
      },
      {
        "label": "B",
        "text": "Al(OH)₃"
      },
      {
        "label": "C",
        "text": "KOH"
      },
      {
        "label": "D",
        "text": "Mg(OH)₂"
      }
    ],
    "answer": "C"
  },
  {
    "id": 54,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "Which base is used to neutralize acidity in the stomach?",
    "options": [
      {
        "label": "A",
        "text": "Ca(OH)₂"
      },
      {
        "label": "B",
        "text": "NaOH"
      },
      {
        "label": "C",
        "text": "Mg(OH)₂"
      },
      {
        "label": "D",
        "text": "KOH"
      }
    ],
    "answer": "C"
  },
  {
    "id": 55,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "What is the colour of Ca(OH)₂?",
    "options": [
      {
        "label": "A",
        "text": "Blue"
      },
      {
        "label": "B",
        "text": "Green"
      },
      {
        "label": "C",
        "text": "White"
      },
      {
        "label": "D",
        "text": "Red"
      }
    ],
    "answer": "C"
  },
  {
    "id": 56,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "Which is NOT a mineral acid?",
    "options": [
      {
        "label": "A",
        "text": "HCl"
      },
      {
        "label": "B",
        "text": "H₂SO₄"
      },
      {
        "label": "C",
        "text": "HNO₃"
      },
      {
        "label": "D",
        "text": "H₂CO₃"
      }
    ],
    "answer": "D"
  },
  {
    "id": 57,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "The total number of elements known till now is:",
    "options": [
      {
        "label": "A",
        "text": "102"
      },
      {
        "label": "B",
        "text": "109"
      },
      {
        "label": "C",
        "text": "118"
      },
      {
        "label": "D",
        "text": "126"
      }
    ],
    "answer": "C"
  },
  {
    "id": 58,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "Besides valuable chemicals, the black residue of coal tar is called:",
    "options": [
      {
        "label": "A",
        "text": "Peat"
      },
      {
        "label": "B",
        "text": "Pitch"
      },
      {
        "label": "C",
        "text": "Coke"
      },
      {
        "label": "D",
        "text": "Lignite"
      }
    ],
    "answer": "B"
  },
  {
    "id": 59,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "Which is a substitution reaction?",
    "options": [
      {
        "label": "A",
        "text": "Halogenation of alkynes"
      },
      {
        "label": "B",
        "text": "Halogenation of alkenes"
      },
      {
        "label": "C",
        "text": "Halogenation of alkanes"
      },
      {
        "label": "D",
        "text": "Bromination of alkenes"
      }
    ],
    "answer": "C"
  },
  {
    "id": 60,
    "paper": "Paper 12",
    "section": "First Half Book — Chapters 9 to 12",
    "question": "Oxidation of alkenes produces:",
    "options": [
      {
        "label": "A",
        "text": "Glyoxal"
      },
      {
        "label": "B",
        "text": "Glycol"
      },
      {
        "label": "C",
        "text": "Oxalic acid"
      },
      {
        "label": "D",
        "text": "Formic acid"
      }
    ],
    "answer": "B"
  },
  {
    "id": 61,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "A pentahydroxy aldehyde is:",
    "options": [
      {
        "label": "A",
        "text": "Starch"
      },
      {
        "label": "B",
        "text": "Glucose"
      },
      {
        "label": "C",
        "text": "Fructose"
      },
      {
        "label": "D",
        "text": "Sucrose"
      }
    ],
    "answer": "B"
  },
  {
    "id": 62,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "The source of galactose is:",
    "options": [
      {
        "label": "A",
        "text": "Fruits"
      },
      {
        "label": "B",
        "text": "Rice"
      },
      {
        "label": "C",
        "text": "Cotton"
      },
      {
        "label": "D",
        "text": "Cellulose"
      }
    ],
    "answer": "A"
  },
  {
    "id": 63,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "Night blindness is caused by deficiency of:",
    "options": [
      {
        "label": "A",
        "text": "Vitamin A"
      },
      {
        "label": "B",
        "text": "Vitamin E"
      },
      {
        "label": "C",
        "text": "Vitamin C"
      },
      {
        "label": "D",
        "text": "Vitamin D"
      }
    ],
    "answer": "A"
  },
  {
    "id": 64,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "The percentage amount of argon in air is:",
    "options": [
      {
        "label": "A",
        "text": "78.09%"
      },
      {
        "label": "B",
        "text": "20.94%"
      },
      {
        "label": "C",
        "text": "0.93%"
      },
      {
        "label": "D",
        "text": "0.3%"
      }
    ],
    "answer": "C"
  },
  {
    "id": 65,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "The main cause of global warming is:",
    "options": [
      {
        "label": "A",
        "text": "CO"
      },
      {
        "label": "B",
        "text": "O₂"
      },
      {
        "label": "C",
        "text": "CO₂"
      },
      {
        "label": "D",
        "text": "O₃"
      }
    ],
    "answer": "C"
  },
  {
    "id": 66,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "Which is a secondary pollutant?",
    "options": [
      {
        "label": "A",
        "text": "CO"
      },
      {
        "label": "B",
        "text": "CO₂"
      },
      {
        "label": "C",
        "text": "SO₃"
      },
      {
        "label": "D",
        "text": "HF"
      }
    ],
    "answer": "C"
  },
  {
    "id": 67,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "The boiling point of water is:",
    "options": [
      {
        "label": "A",
        "text": "0°C"
      },
      {
        "label": "B",
        "text": "25°C"
      },
      {
        "label": "C",
        "text": "80°C"
      },
      {
        "label": "D",
        "text": "100°C"
      }
    ],
    "answer": "D"
  },
  {
    "id": 68,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "Which gas is used to destroy harmful bacteria in water?",
    "options": [
      {
        "label": "A",
        "text": "Iodine"
      },
      {
        "label": "B",
        "text": "Chlorine"
      },
      {
        "label": "C",
        "text": "Fluorine"
      },
      {
        "label": "D",
        "text": "Bromine"
      }
    ],
    "answer": "B"
  },
  {
    "id": 69,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "Which disease is caused by a protozoan?",
    "options": [
      {
        "label": "A",
        "text": "Dysentery"
      },
      {
        "label": "B",
        "text": "Cholera"
      },
      {
        "label": "C",
        "text": "Cryptosporidium"
      },
      {
        "label": "D",
        "text": "Hepatitis"
      }
    ],
    "answer": "C"
  },
  {
    "id": 70,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "The formula of copper glance is:",
    "options": [
      {
        "label": "A",
        "text": "CuFeS₂"
      },
      {
        "label": "B",
        "text": "CuS"
      },
      {
        "label": "C",
        "text": "CuS₂"
      },
      {
        "label": "D",
        "text": "Cu₂S"
      }
    ],
    "answer": "D"
  },
  {
    "id": 71,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "In Solvay's process, slaked lime is used to:",
    "options": [
      {
        "label": "A",
        "text": "Prepare CO₂"
      },
      {
        "label": "B",
        "text": "Prepare quick lime"
      },
      {
        "label": "C",
        "text": "Recover ammonia"
      },
      {
        "label": "D",
        "text": "Form Na₂CO₃"
      }
    ],
    "answer": "C"
  },
  {
    "id": 72,
    "paper": "Paper 13",
    "section": "Second Half Book — Chapters 13 to 16",
    "question": "The molecular formula of octane found in petrol is:",
    "options": [
      {
        "label": "A",
        "text": "C₈H₈"
      },
      {
        "label": "B",
        "text": "C₈H₁₆"
      },
      {
        "label": "C",
        "text": "C₈H₁₈"
      },
      {
        "label": "D",
        "text": "C₈H₂₀"
      }
    ],
    "answer": "C"
  }
];
