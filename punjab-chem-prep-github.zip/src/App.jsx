import React, { useEffect, useMemo, useState } from 'react'
import { questions } from './questions'

const LETTERS = ['A','B','C','D']
const STORAGE = 'punjab-chem-prep-v1'

function loadStats(){
  try { return JSON.parse(localStorage.getItem(STORAGE)) || {best:0,taken:0,attempted:0,correct:0} }
  catch { return {best:0,taken:0,attempted:0,correct:0} }
}
function saveStats(s){ localStorage.setItem(STORAGE, JSON.stringify(s)) }

const sets = [
  {id:'Paper 08', title:'Chapter Wise — Chapter 16'},
  {id:'Paper 09', title:'First Quarter — Units 9 to 11'},
  {id:'Paper 10', title:'Second Quarter — Units 12 to 14'},
  {id:'Paper 11', title:'Third Quarter — Units 15 to 16'},
  {id:'Paper 12', title:'First Half Book — Chapters 9 to 12'},
  {id:'Paper 13', title:'Second Half Book — Chapters 13 to 16'},
]

function shuffle(arr){
  return [...arr].sort(() => Math.random() - 0.5)
}

export default function App(){
  const [screen,setScreen] = useState('home')
  const [mode,setMode] = useState(null)
  const [testQuestions,setTestQuestions] = useState([])
  const [answers,setAnswers] = useState({})
  const [current,setCurrent] = useState(0)
  const [flagged,setFlagged] = useState({})
  const [timeLeft,setTimeLeft] = useState(0)
  const [result,setResult] = useState(null)
  const [stats,setStats] = useState(loadStats)
  const [customPaper,setCustomPaper] = useState('all')
  const [shuffleOptions,setShuffleOptions] = useState(false)

  const startTest = (kind, qs, minutes) => {
    const prepared = qs.map(q => {
      if(!shuffleOptions) return q
      return {...q, options: shuffle(q.options)}
    })
    setMode(kind)
    setTestQuestions(prepared)
    setAnswers({})
    setFlagged({})
    setCurrent(0)
    setResult(null)
    setTimeLeft(minutes * 60)
    setScreen('test')
  }

  useEffect(() => {
    if(screen !== 'test') return
    if(timeLeft <= 0){
      if(testQuestions.length) finishTest(true)
      return
    }
    const t = setInterval(() => setTimeLeft(v => v - 1), 1000)
    return () => clearInterval(t)
  }, [screen,timeLeft])

  const score = useMemo(() => testQuestions.reduce((n,q) => n + (answers[q.id] === q.answer ? 1 : 0),0), [testQuestions,answers])

  function finishTest(auto=false){
    if(!testQuestions.length) return
    const correct = testQuestions.reduce((n,q)=>n+(answers[q.id]===q.answer?1:0),0)
    const attempted = testQuestions.reduce((n,q)=>n+(answers[q.id]?1:0),0)
    const pct = Math.round(correct / testQuestions.length * 100)
    const next = {
      best: Math.max(stats.best || 0, pct),
      taken: (stats.taken || 0) + 1,
      attempted: (stats.attempted || 0) + attempted,
      correct: (stats.correct || 0) + correct
    }
    setStats(next); saveStats(next)
    setResult({correct,attempted,pct,auto})
    setScreen('result')
  }

  const minutes = String(Math.floor(timeLeft/60)).padStart(2,'0')
  const seconds = String(timeLeft%60).padStart(2,'0')

  if(screen === 'home') return (
    <Home
      stats={stats}
      customPaper={customPaper}
      setCustomPaper={setCustomPaper}
      shuffleOptions={shuffleOptions}
      setShuffleOptions={setShuffleOptions}
      onFull={() => startTest('Full Test', questions, 90)}
      onSet={(id) => startTest(id, questions.filter(q=>q.paper===id), 15)}
      onRandom={(n,m) => startTest(`Random ${n}`, shuffle(questions).slice(0,n), m)}
      onCustom={() => {
        const qs = customPaper === 'all' ? questions : questions.filter(q=>q.paper===customPaper)
        if(qs.length) startTest('Custom Test', shuffle(qs), Math.min(90, Math.max(15, Math.ceil(qs.length*1.25))))
      }}
    />
  )

  if(screen === 'test') return (
    <TestScreen
      title={mode}
      questions={testQuestions}
      answers={answers}
      setAnswers={setAnswers}
      current={current}
      setCurrent={setCurrent}
      flagged={flagged}
      setFlagged={setFlagged}
      time={`${minutes}:${seconds}`}
      score={score}
      onFinish={() => finishTest(false)}
    />
  )

  return <ResultScreen result={result} questions={testQuestions} answers={answers} onHome={()=>setScreen('home')} onRetry={()=>startTest(mode,testQuestions,Math.max(15,Math.ceil(testQuestions.length*1.25/1)))}/>
}

function Home({stats,customPaper,setCustomPaper,shuffleOptions,setShuffleOptions,onFull,onSet,onRandom,onCustom}){
  const accuracy = stats.attempted ? Math.round(stats.correct/stats.attempted*100) : 0
  return <div className="page">
    <header className="topbar">
      <div>
        <div className="brand-small">Hamdard Up-to-Date Papers</div>
        <h1>Chemistry MCQ Test Portal</h1>
        <p>10th Class — Supply Exam Preparation</p>
      </div>
      <div className="badge">Punjab Board</div>
    </header>

    <section className="stats">
      <Stat value={questions.length} label="MCQs"/>
      <Stat value={sets.length} label="Test Sets"/>
      <Stat value={`${stats.best || 0}%`} label="Best Score"/>
      <Stat value={stats.taken || 0} label="Tests Taken"/>
      <Stat value={stats.attempted || 0} label="Attempted"/>
      <Stat value={`${accuracy}%`} label="Accuracy"/>
    </section>

    <section className="hero-card">
      <div>
        <span className="eyebrow">FULL PRACTICE</span>
        <h2>Full Test — {questions.length} MCQs</h2>
        <p>All uploaded papers & chapters · 90 minutes</p>
      </div>
      <button className="primary" onClick={onFull}>Start Full Test →</button>
    </section>

    <section>
      <div className="section-head">
        <h2>Test Sets</h2><span>12 MCQs each · 15 minutes</span>
      </div>
      <div className="grid">
        {sets.map((s,i)=><button className="card" key={s.id} onClick={()=>onSet(s.id)}>
          <div className="number">{String(i+8).padStart(2,'0')}</div>
          <div><strong>{s.id}</strong><p>{s.title}</p><small>12 MCQs · 15 min</small></div>
          <span className="arrow">→</span>
        </button>)}
      </div>
    </section>

    <section className="two-col">
      <div className="panel">
        <div className="section-head"><h2>Random Practice</h2></div>
        <div className="random-row">
          <button onClick={()=>onRandom(20,25)}><b>Random 20</b><span>25 minutes</span></button>
          <button onClick={()=>onRandom(30,35)}><b>Random 30</b><span>35 minutes</span></button>
        </div>
      </div>
      <div className="panel">
        <div className="section-head"><h2>Custom Test</h2></div>
        <select value={customPaper} onChange={e=>setCustomPaper(e.target.value)}>
          <option value="all">All Questions</option>
          {sets.map(s=><option key={s.id} value={s.id}>{s.id} — {s.title}</option>)}
        </select>
        <label className="check"><input type="checkbox" checked={shuffleOptions} onChange={e=>setShuffleOptions(e.target.checked)}/> Shuffle options</label>
        <button className="primary wide" onClick={onCustom}>Start Custom Test</button>
      </div>
    </section>

    <footer>
      <span>{questions.length} questions loaded locally</span>
      <span>Progress is saved in this browser</span>
    </footer>
  </div>
}

function Stat({value,label}){ return <div className="stat"><strong>{value}</strong><span>{label}</span></div> }

function TestScreen({title,questions,answers,setAnswers,current,setCurrent,flagged,setFlagged,time,onFinish}){
  const q=questions[current]
  const progress=Math.round((current+1)/questions.length*100)
  const choose=(letter)=>setAnswers(a=>({...a,[q.id]:letter}))
  return <div className="test-page">
    <header className="testbar">
      <button className="back" onClick={()=>window.confirm('Exit this test? Your current answers will be lost.') && location.reload()}>← Exit</button>
      <div><b>{title}</b><span>{current+1} / {questions.length}</span></div>
      <div className="timer">⏱ {time}</div>
    </header>
    <div className="progress"><div style={{width:`${progress}%`}}/></div>

    <main className="test-main">
      <div className="q-top">
        <span className="pill">{q.paper}</span>
        <button className={flagged[q.id]?'flag active':'flag'} onClick={()=>setFlagged(f=>({...f,[q.id]:!f[q.id]}))}>
          {flagged[q.id]?'★ Marked':'☆ Mark for review'}
        </button>
      </div>
      <p className="section-label">{q.section}</p>
      <h2 className="question">{q.question}</h2>

      <div className="options">
        {q.options.map(opt=>{
          const selected=answers[q.id]===opt.label
          return <button key={opt.label} className={selected?'option selected':'option'} onClick={()=>choose(opt.label)}>
            <span className="letter">{opt.label}</span><span>{opt.text}</span>
          </button>
        })}
      </div>

      <div className="nav">
        <button disabled={current===0} onClick={()=>setCurrent(v=>v-1)}>← Previous</button>
        {current < questions.length-1
          ? <button className="primary" onClick={()=>setCurrent(v=>v+1)}>Next →</button>
          : <button className="submit" onClick={onFinish}>Submit Test</button>}
      </div>

      <div className="palette">
        <div className="palette-head"><b>Questions</b><span>{Object.keys(answers).length} answered · {Object.keys(flagged).filter(k=>flagged[k]).length} marked</span></div>
        <div className="dots">{questions.map((x,i)=><button key={x.id} className={`${i===current?'current ':''}${answers[x.id]?'answered ':''}${flagged[x.id]?'marked':''}`} onClick={()=>setCurrent(i)}>{i+1}</button>)}</div>
      </div>
    </main>
  </div>
}

function ResultScreen({result,questions,answers,onHome,onRetry}){
  return <div className="result-page">
    <div className="result-card">
      <div className="result-icon">{result.pct>=80?'✓':'!'}</div>
      <span className="eyebrow">TEST COMPLETE</span>
      <h1>{result.pct}%</h1>
      <p className="big">{result.correct} / {questions.length} correct</p>
      <div className="result-grid">
        <div><b>{result.correct}</b><span>Correct</span></div>
        <div><b>{questions.length-result.correct}</b><span>Incorrect</span></div>
        <div><b>{questions.length-result.attempted}</b><span>Unattempted</span></div>
      </div>
      {result.auto && <p className="notice">Time was up, so the test was submitted automatically.</p>}
      <div className="result-actions">
        <button className="primary" onClick={onRetry}>Try Again</button>
        <button onClick={onHome}>Back to Home</button>
      </div>
    </div>

    <div className="review">
      <h2>Answer Review</h2>
      {questions.map((q,i)=>{
        const chosen=answers[q.id]
        return <div className={`review-item ${chosen===q.answer?'ok':'wrong'}`} key={q.id}>
          <div><b>Q{i+1}.</b> {q.question}</div>
          <small>Your answer: <b>{chosen || 'Not answered'}</b> · Correct: <b>{q.answer}</b></small>
        </div>
      })}
    </div>
  </div>
}
