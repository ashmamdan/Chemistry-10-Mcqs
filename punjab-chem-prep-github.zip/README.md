# Punjab Chemistry MCQ Practice

A mobile-friendly React/Vite MCQ practice portal for 10th Class Punjab Board Chemistry.

## Included
- 72 MCQs from Papers 08–13
- Full test
- 12-question paper sets
- Random 20 / Random 30
- Custom source selection
- Timer and automatic submission
- Question palette
- Mark for review
- Results + answer review
- Browser-local statistics
- GitHub Pages workflow

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Add more MCQs
Edit `src/questions.js`. Each question has:
`id`, `paper`, `section`, `question`, `options`, `answer`.

The app intentionally keeps the question bank local, so it works as a static GitHub Pages site without a database.
